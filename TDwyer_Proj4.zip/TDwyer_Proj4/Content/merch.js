﻿<script>
    function myFunction() {
  var x = document.getElementById("myDIV");
  if (x.innerHTML === "Hello") {
        x.innerHTML = "Swapped text!";
    } else {
        x.innerHTML = "Hello";
    }
  }
</script>